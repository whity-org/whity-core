# Whity brand kit (3.3)

- `logos/`: the mark, lockups (colour, ink, on brand), app icons, favicons, "Built on Whity" badges, and PNG exports.
- `icons/`: the icon set (Tabler, MIT; see LICENSE-tabler.txt) as used in Whity.
- `motion/`: the Lottie files and their rules (README).
- `tokens.flat.json`: colours, type, spacing and radii.

The name and the mark are trademarks: see https://brand.whity.dev for how to use them. The main blue is #0961bb.
